## Blank Canvas Weather
### An Obligatory Weather App

This is a weather app made using the OpenWeatherMap API and jQuery. Animations were created using HTML5 Canvas. Icons are from Noun Project.

I created this web app for a Free Code Camp Zipline. I wanted to spend some time learning/using jQuery and HTML5 Canvas. This is basically my first app, so there's a lot of room for improvement.
